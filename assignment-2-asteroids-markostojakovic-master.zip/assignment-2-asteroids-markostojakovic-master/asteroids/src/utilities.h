int rTravel(int from, int to);

float radians(float a);
