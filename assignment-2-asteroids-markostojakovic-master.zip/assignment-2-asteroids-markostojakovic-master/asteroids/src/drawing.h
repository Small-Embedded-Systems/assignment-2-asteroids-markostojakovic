void draw(void);
void createLasers(struct laser * lst);
void createAsteroids(struct asteroid * lst);
void shield(void);
void switchBuffers(void);
void startDoubleBuffering(void);
void gameEnd(void);
void screen(void);
