#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <display.h>
#include <mbed.h>
#include <utilities.h>
#include <controls.h>
#include <physics.h>

//declared variables
static const int heapsize = 5;
static const int astHeapsize = 9;
static node_t heap[heapsize];
static asteroid_t astheap[astHeapsize];
static node_t * fNodes;		//fNodes=freeNodes
static asteroid_t * astFNodes;
int headingAngle;
float headingAngleRadians;
float originX;
float originY;
float pointX;
float pointY;
float leftX;
float leftY;
float rightX;
float rightY;
double score;
double speed;
double accel;
int lives;
int shieldHealth;
int endScore;
int activeTime;
int activeTimeTotal;
int immunity;

static const float Dt = 0.01;
struct laser * active = NULL;
struct asteroid * astactive = NULL;

void physics(void){
    checkShipStrength(astactive);
    checkLaserHit(active, astactive);
    update(active);
    renewAsteroid(astactive);
    wrapAround();
    headingAngleRadians = radians(headingAngle);
    pointX = 10 * (cos(headingAngleRadians));
  	pointY = 10 * (sin(headingAngleRadians));
  	leftX = ( -5 * (cos(headingAngleRadians))) - ( 5 * (sin(headingAngleRadians)));
  	leftY = ( -5 * (sin(headingAngleRadians))) + ( 5 * (cos(headingAngleRadians)));
  	rightX = ( -5 * (cos(headingAngleRadians))) - ( -5 *(sin(headingAngleRadians)));;
  	rightY = ( -5 * (sin(headingAngleRadians))) + ( -5 * (cos(headingAngleRadians)));;
  	originX = originX + speed * (cos(headingAngleRadians));
  	originY = originY + speed * (sin(headingAngleRadians));
	  score++;
		if( speed < 5 ){
			speed = speed + accel;
		}
		if( accel > 0 ){
			accel = accel - 0.1;
		}
		if( speed > 0 ){
			speed = speed - 0.01;
		}
		time();
		if( immunity > 0 ){
			immunity--;
		}
}

//initial values
void initValues(void){
	originX = 180;
	originY = 130;
	headingAngle = 90;
	score = 0.0;
	shieldHealth = 3;
	endScore = 0;
	accel = 0.0;
	immunity = 100;
}

//check shield upon collision
void checkShipStrength(struct asteroid * c){
    for( ; c ; c = c->next ) {
        if(c->asteroidX<(originX + 8) && c->asteroidX>(originX - 8)){
          if(c->asteroidY<(originY + 8) && c->asteroidY>(originY - 8)){
            if(shieldHealth > 0){
							if(immunity == 0){
								shieldHealth--;
								immunity = 50;
							}
						} else if(shieldHealth <= 0){
							if(immunity == 0){
								if(lives > 0){
									lives--;
								}
								originX = 240;
								originY = 130;
								headingAngle = 90;
								speed = 0;
								activeTimeTotal = activeTimeTotal + activeTime;
								score = 0;
								immunity = 50;
							}
						}
          }
        }
    }
}

//laserhit
void checkLaserHit(struct laser * a, struct asteroid * b) {
  for(; a ; a = a->next){
    for(; b ; b = b->next){
      if(a->x > (b->asteroidX - 12) && a->x < (b->asteroidX + 12)){
        if(a->y > (b->asteroidY - 12) && a->y < (b->asteroidY + 12)){
          a->ttl = 0;
          b->asteroidTtl = 0;
        }
      }

      }
    }
 }

//laser collision with asteroid
 void update(struct laser * l){
    for( ; l ; l = l->next ) {
        l->x += l->v_x * Dt;
        l->y += l->v_y * Dt;
        if( l->x <0 || 480 <l->x ) l->ttl=0;
        if( l->y<10 || 260 <l->y ) l->ttl=0;
        l->ttl -= Dt;
        if( l-> next->ttl <= 0 ) {
            struct laser * expired = l-> next;
            l->next = l->next->next;
            freeNode(expired);
        }
    }
}

void wrapAround(void){
  if(originX > 480){
		originX = 5;
	} else if(originX < 0){
		originX = 475;
	} else if(originY > 260){
		originY = 25;
	} else if(originY < 20){
		originY = 255;
	}
}

void renewAsteroid(struct asteroid * l){
    for( ; l ; l = l->next ) {
        l->asteroidX += l->asteroidV_x * Dt;
        l->asteroidY += l->asteroidV_y * Dt;
        if( l->asteroidX<-20 || 500<l-> asteroidX ) l->asteroidTtl=0;
        if( l->asteroidY<25 || 280<l-> asteroidY ) l->asteroidTtl=0;
        l->asteroidTtl -= Dt;
        if( l->next->asteroidTtl <= 0 ) {
            struct asteroid * expired = l-> next;
            l->next = l->next->next;
            astFNode(expired);
        }
    }
}

//speed and direction of lasers
void strike(struct laser * r){
    r->x = originX;
    r->y = originY;
    r->v_x = 200 * (cos(headingAngleRadians));
    r->v_y = 200 * (sin(headingAngleRadians));
    r->ttl = 200;
}

//score calculated by time played
void time(void){
	activeTime = (int)((score/100) + 0.5);
}

//range of onscreen asteroids
void strike(struct asteroid * r){
    r->asteroidX = rTravel(50,435);
    r->asteroidY = rTravel(35,210);
    r->asteroidV_x = rTravel(-5,5);
    r->asteroidV_y = rTravel(-5,5);
    r->asteroidTtl = rTravel(900,1100);
}

//checks if asteroids are active on display
void asteroidSystem(void){
        struct asteroid * asteroidspark = astallocatenode();
        if(asteroidspark) {
            asteroidspark->next = astactive;
            astactive = asteroidspark;
            strike(asteroidspark);
        }
}

void loadHeap(void){
    int n;
    for( n = 0 ; n<(heapsize - 1) ; n++) {
        heap[n].next = &heap[n+1];
    }
    heap[n].next = NULL;
    fNodes = &heap[0];
}

//Active missile system 
void laserSystem(void){
        struct laser * spark = allocnode();
        if(spark) {
            spark->next = active;
            active = spark;
            strike(spark);
        }
}

//Total asteroids
void loadAsteroidHeap(void){
    int n;
    for( n = 0 ; n<(astHeapsize - 1) ; n++) {
        astheap[n].next = &astheap[n + 1];
    }
    astheap[n].next = NULL;
    astFNodes = &astheap[0];
}

node_t * allocnode(void){
    node_t * node = NULL;
    if( fNodes ) {
        node = fNodes;
        fNodes = fNodes->next;
    }
    return node;
}

asteroid_t * astallocatenode(void){
    asteroid_t * node = NULL;
    if( astFNodes ) {
        node = astFNodes;
        astFNodes = astFNodes->next;
    }
    return node;
}

void freeNode(node_t * n){
    n->next = fNodes;
    fNodes = n;
}

void astFNode(asteroid_t * n){
    n->next = astFNodes;
    astFNodes = n;
}
