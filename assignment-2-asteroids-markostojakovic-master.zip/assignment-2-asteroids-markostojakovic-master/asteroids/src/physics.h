//Laser code	
typedef struct laser {
    float x,y;
    float v_x, v_y;
    float ttl;
    struct laser *next;
} node_t;

//Asteroid code
typedef struct asteroid {
    float asteroidX,asteroidY;
    float asteroidV_x, asteroidV_y;
    float asteroidTtl;
    struct asteroid *next;
} asteroid_t;

//Ship Variable
extern int headingAngle;
extern float headingAngleRadians;
extern float originX;
extern float originY;
extern float pointX;
extern float pointY;
extern float leftX;
extern float leftY;
extern float rightX;
extern float rightY;
extern double score;
extern struct laser *active;
extern struct asteroid *astactive;
extern double speed;
extern double accel;
extern int lives;
extern int shieldHealth;
extern int endScore;
extern int activeTime;
extern int activeTimeTotal;
extern int immunity;
extern const int heapsize;
extern const int astHeapsize;

//Physics of lasers and asteroids
void physics(void);
void checkShipStrength(struct asteroid * c);
void checkLaserHit(struct laser *a, struct asteroid * b);
void update(struct laser * l);
void renewAsteroid(struct asteroid * l);
void wrapAround(void);
void time(void);
void strike(struct laser * r);
void strike(struct asteroid * r);
void laserSystem(void);
void asteroidSystem(void);
void loadHeap(void);
void loadAsteroidHeap(void);
node_t *allocnode(void);
asteroid_t *astallocatenode(void);
void freeNode(node_t * n);
void astFNode(asteroid_t * n);
void initValues(void);
